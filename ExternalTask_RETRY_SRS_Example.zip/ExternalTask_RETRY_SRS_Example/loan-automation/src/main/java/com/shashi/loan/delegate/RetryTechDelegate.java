package com.shashi.loan.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

/*
Working as expected
COnfiguration: R3/PT5M
Repeat 3 times @ 5 min interval
 */
@Component
public class RetryTechDelegate implements JavaDelegate {

    int i = 1;

    @Override
    public void execute(DelegateExecution delegateExecution) throws Exception {

        System.out.println("--- STARTED --- " + i++);

        System.out.println("::::" + delegateExecution.getVariables());
        int number1 = Integer.parseInt(delegateExecution.getVariable("number1").toString());
        int number2 = Integer.parseInt(delegateExecution.getVariable("number2").toString());
        System.out.println("Outcome::: " + number1 / number2);

        System.out.println("--- END ---");
    }
}
