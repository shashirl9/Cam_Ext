https://docs.camunda.org/manual/7.20/user-guide/process-engine/external-tasks/

https://camunda.com/blog/2021/03/external-task-client-spring-bootified/ ************
https://docs.camunda.org/manual/7.20/user-guide/ext-client/spring-boot-starter/
https://github.com/tasso94/external-task-client-spring-boot-starter-example


https://www.youtube.com/watch?v=hSySzjmIIz4&ab_channel=ImagineCode
https://www.youtube.com/watch?v=8DXoV_OGo7s&ab_channel=Dpoint
https://dzone.com/articles/external-task-client-in-camunda-with-spring-boot-a


RETRY
=====
https://forum.camunda.io/t/define-retries-on-external-task-in-camunda-modeler/14351/4  *******
https://docs.camunda.org/manual/7.10/user-guide/process-engine/external-tasks/?__hstc=218867270.70bea9548f80e50687677fd0e6a66e8f.1710128426820.1710128426820.1710150679380.2&__hssc=218867270.1.1710150679380&__hsfp=1057798545&_gl=1*19eqk4m*_ga*NjE1MjgxODUxLjE3MTAxMjg0Mzc.*_ga_4EYN8X5FNR*MTcxMDE1MDY4NS4yLjEuMTcxMDE1MTE0OC42MC4wLjA.#reporting-task-failure
https://blog.viadee.de/en/camunda-external-tasks-error-handling-and-retry-behavior